from django.shortcuts import render
from django.http import HttpResponse
from django.contrib.auth.froms import authenticationForm
from django.contrib.auth.import.login, logout, authenticate
from .forms import NewUserForm
# Create your views here.
def homepage(request):
    return HttpResponse("Tutorial")







def logout_request(request):
    logout(request)
    messages.info(request, "Logged out successfully!" )
    return redirect("main:homepage")

def login_request(request):
    if request.method == "POST":
        form = authenticationForm(request, data=request.POST)
        if form.is_valid():
            username = form.cleand_data.get('username')
            password = form.cleand_data.get('password')
            user = authenticate(username=username,password= password)
            if user is not None:
                login(request, user)
                messages.info(request,f"You are now logged in as {username}")
                return redirect("main:homepage")
            else:
                messages.error(request,"invalid username or password")
        else:
            messages.error(request,"invalid username or password")
    form = authenticationForm()
    return render(request,
                  "main/login.html",
                  {"form":form})