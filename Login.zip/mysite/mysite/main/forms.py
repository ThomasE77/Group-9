from django import froms
from django.contrib.auth.froms import UserCreationForm
from django.contrib.auth.models import User


class NewUserForm(UserCreationForm):
    email = forms.Emailfield(required=True)

    class Meta:
        model = User
        fields =("username" , "email" , "password1", "password2")

    def save(self, commit=True):
        user = super(NewUserForm, self).save(commit=False)
        user.email = self.cleand_data['email']
        if commit:
            user.save()
        return user 